# Table of Contents
- [Table of Contents](#table-of-contents)
- [Introduction](#introduction)

# Introduction

Cryptoprice was created with the intention of making it easy to keep track of your portfolio and monitor the market all in the command line. This project is a work in progress. I will actively work on it and update it with new features. If you have an idea about a feature you would like implemented, please open a new issue.